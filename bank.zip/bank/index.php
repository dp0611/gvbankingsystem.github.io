<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       
        
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/css/bootstrap.min.css" integrity="sha384-VCmXjywReHh4PwowAiWNagnWcLhlEJLA5buUprzK8rxFgeH0kww/aWY76TfkUoSX" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="style.css" media="all">
        
        <title>index</title>
    </head>
    
    <body>
        
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto pl-0 pl-sm-1">
                        <li class="nav-item active">
							<h4><a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>&nbsp
                        <li class="nav-item">
							<h4><a class="nav-link" href="about.php">About Us</a>
                        </li>&nbsp
                        <li class="nav-item">
                            <h4><a class="nav-link" href="customer.php">View Customers</a>
                        </li>&nbsp
                        <li class="nav-item">
                            <h4><a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                    </ul>
                
                </div>
            </nav>
        </div>


        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="images/home.jpg" class="d-block w-10" alt="..." height="380px" width="1500px" >
                    <div class="carousel-caption d-none d-md-block" style="top: 90px;">
                        <h1><font size="7">Welcome to Green Valley Banking System</font></h1><br><br><br><br><br><br><br>
						<marquee>Banking solutions on your tips </marquee>
                        <p></p>
                    </div>
                </div>
                
                
            </div>
           
        </div>

        <div class="container mt-3">
		
		
		<table border="0"  width="100%" >
			<tr>
					<td><img src="images/li.png" class="d-block w-10" alt="..." height="15%" width="15%"  align="right">&nbsp </td>
					<td><h1><center>&nbsp Green Valley Banking Systems</center></h1></td>
					<td><img src="images/li.png" class="d-block w-10" alt="..." height="15%" width="15%"  align="left"></td>
			</tr>
		</table>
		<br>
		       
                    <span>					 
                        <p style="text-align: left;">
                            This is a demo website by <a href="" style="text-decoration: none;">Deepak Sharma</a> in partial fullfillment of the internship opportunity provided to 
							me by <a href="https://www.linkedin.com/in/the-sparks-foundation/" style="text-decoration: none;">The Sparks Foudation</a>.<br>
							Here you can view all the customers associated with our bank, and also you can make transfer from one customer's account to another. <br>
							 This is the demo for the task #1 in Web and app designing internship domain.<br>
							<h3>Flow of the website - </h3> Home Page > View All Customers > Select and View One Customer > Transfer Money > View All Customers.
						</p>
						
                    </span>
                </div>
            </div>
            
          <br>
       


        <div class="text-center bg-dark footer">
            @2020 || Green Valley Banking Systems
           
        </div>
        
       
    </body>
</html>
